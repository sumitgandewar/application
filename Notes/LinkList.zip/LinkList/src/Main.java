

public class Main {

	public static void main(String[] args) {
		
		LinkList list = new LinkList();
		list.append(10);
		list.insert(20);
		list.append(100);
		list.insert(200);
		list.append(1000);
		list.insert(2000);
		System.out.println(list);		
		
	}
}
