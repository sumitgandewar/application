1.  Perfect number -
    a positive integer that is equal to the sum of its proper divisors. The smallest perfect number is 6, which is the sum of 1, 2, and 3.

2.  A palindromic number -
    is a number that remains the same when its digits are reversed.

3.  Strong numbers -
    are the numbers whose sum of factorial of digits is equal to the original number.
    e.g. - 145
    5=5*4*3*2*1

    - 4=4*3*2\*1
    - 1=1

    ***

         145

4.  Fibonacci number
    a series of numbers in which each number ( Fibonacci number ) is the sum of the two preceding numbers. The simplest is the series 0, 1, 1, 2, 3, 5, 8, etc.

5.  GCD (Greatest Common Divisor) is known as HCF.

6.  Armstrong number -
    An Armstrong number is an integer such that the sum of the power of its digits is equal to the number itself.
    For example, 371 is an Armstrong number since
    3^3 + 7^3 + 1^3 = 371.
    9 is an Armstrong number since 9\*1= 9.

7.  PANAGRAM - a sentence containing every letter of the alphabet.(all 26)
